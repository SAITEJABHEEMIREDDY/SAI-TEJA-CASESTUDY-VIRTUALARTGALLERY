package com.virtualartgallery.dao;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.virtualartgallery.entity.Artist;
import com.virtualartgallery.entity.Gallery;
import com.virtualartgallery.exception.GalleryNotFoundException;
import com.virtualartgallery.util.DBConnection;

class GalleryDAOImplTest {
	
	private static Connection connection;
	private static IGalleryDAO iGalleryDAO;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		iGalleryDAO = new GalleryDAOImpl();
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		iGalleryDAO = null;
	}

	@BeforeEach
	void setUp() throws Exception {
		connection = DBConnection.getConnection();
	}

	@AfterEach
	void tearDown() throws Exception {
		connection.close();
	}

	@Test
	void testAddGallery() {
		int result = 0;
		Artist artist = new Artist(18,"Mahesh","Best artist in Hand arts","1987-12-25","Indian","www.mahiarts.com","0503081888");
		
		Gallery gallery = new Gallery("gname","location","openingHour","description",artist);
		try {
			result = iGalleryDAO.addGallery(gallery);
		}catch(ClassNotFoundException cfne) {
			System.out.println("Looks like JDBC driver is not loaded");
		}catch(SQLException s) {
			s.printStackTrace();
			System.out.println("Either url,username or password is wrong or duplicate record");
		}
		assertTrue(result!=0);
	}

	@Test
	void testUpdateGallery() {
		int result = 0;
		Artist artist = new Artist(18,"Mahesh","Best artist in Hand arts","1987-12-25","Indian","www.mahiarts.com","0503081888");
		
		Gallery gallery = new Gallery(215,"HandArts","Bur Dubai","Day","Famous Hand Arts",artist);
		try {
			result = iGalleryDAO.updateGallery(gallery);
		}catch(SQLException s) {
			System.out.println("Error in your Query");
			s.getMessage();
		}catch(GalleryNotFoundException gnfe) {
			System.out.println("Gallery Not Found Enter Correct Gallery ID");
			gnfe.getMessage();
		}catch(ClassNotFoundException cnfe) {
			System.out.println("JDBC is not Connected Properly");
			cnfe.getMessage();
		}
		
		assertTrue(result!=0);
	}

	@Test
	void testDeleteGallery() {
		int galleryId = 216;
		int result = 0;
		try {
			result = iGalleryDAO.deleteGallery(galleryId);
		}catch(ClassNotFoundException cfne) {
			System.out.println("Looks like JDBC driver is not loaded");
		}catch(SQLException s) {
			s.printStackTrace();
			System.out.println("Either url,username or password is wrong or duplicate record");
		}catch(GalleryNotFoundException gnfe) {
			System.out.println("Gallery Not Found");
		}
		
		assertTrue(result!=0);
	}

	@Test
	void testViewGallery() {
		Gallery gallery = null;
		int galleryId = 209;
		try {
			gallery = iGalleryDAO.viewGallery(galleryId);
		}catch(ClassNotFoundException cfne) {
			System.out.println("Looks like JDBC driver is not loaded");
		}catch(SQLException s) {
			System.out.println("Either url,username or password is wrong or duplicate record");
		}catch(GalleryNotFoundException gnfe) {
			System.out.println("Gallery Not Found Enter Correct GalleryID");
		}
		assertTrue(gallery!=null);
	}

	@Test
	void testViewGallerys() {
		List<Gallery> galleryList = new ArrayList<>();
		try {
			galleryList = iGalleryDAO.viewGallerys();
		}catch(ClassNotFoundException cfne) {
			System.out.println("Looks like JDBC driver is not loaded");
		}catch(SQLException s) {
			s.printStackTrace();
			System.out.println("Either url,username or password is wrong or duplicate record");
		}catch(GalleryNotFoundException gnfe) {
			System.out.println("Gallery Not Found Enter Correct GalleryID");
		}
		assertTrue(galleryList.size()!=0);
	}

}
