package com.virtualartgallery.dao;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.virtualartgallery.entity.ArtWork;
import com.virtualartgallery.entity.User;
import com.virtualartgallery.exception.ArtWorkNotFoundException;
import com.virtualartgallery.exception.FavArtWorkNotFoundException;
import com.virtualartgallery.exception.UserNotFoundException;

public interface IUserDAO {
	
	public int addUser(User user) throws SQLException,ClassNotFoundException,IllegalArgumentException,FileNotFoundException,IOException;
	public int updateUser(User user) throws UserNotFoundException,SQLException,ClassNotFoundException;
	public int deleteUser(int userId) throws UserNotFoundException,SQLException,ClassNotFoundException;
	public List<User>viewUsers() throws UserNotFoundException,SQLException,ClassNotFoundException;
	public User viewUser(int userId) throws UserNotFoundException,SQLException,ClassNotFoundException,FileNotFoundException,IOException;
	
	public int addArtworkToFavorite(int userId,int artWorkId) throws ArtWorkNotFoundException,SQLException,ClassNotFoundException,UserNotFoundException,FavArtWorkNotFoundException;
	public int removeArtworkFromFavorite(int userId, int artWorkId) throws ArtWorkNotFoundException,SQLException,ClassNotFoundException,UserNotFoundException,FavArtWorkNotFoundException;
	public List<ArtWork> getUserFavoriteArtworks(int userId) throws UserNotFoundException,FavArtWorkNotFoundException,SQLException,ClassNotFoundException;

	
}


