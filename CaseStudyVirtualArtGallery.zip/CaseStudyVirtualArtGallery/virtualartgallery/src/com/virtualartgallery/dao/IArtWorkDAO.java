package com.virtualartgallery.dao;

import java.sql.SQLException;
import java.util.List;

import com.virtualartgallery.entity.ArtWork;
import com.virtualartgallery.exception.ArtWorkNotFoundException;
import com.virtualartgallery.exception.GalleryNotFoundException;

public interface IArtWorkDAO {
	
	public int addArtWork(ArtWork artwork) throws SQLException,ClassNotFoundException,IllegalArgumentException;
	public int updateArtWork(ArtWork artwork) throws ArtWorkNotFoundException,SQLException,ClassNotFoundException,IllegalArgumentException ;
	public int removeArtWork(int artWorkid) throws ArtWorkNotFoundException,SQLException,ClassNotFoundException  ;
	public ArtWork getArtWorkById(int artWorkId) throws ArtWorkNotFoundException,SQLException,ClassNotFoundException ;
	public List<ArtWork> searchArtworks(String keyword) throws ArtWorkNotFoundException,SQLException,ClassNotFoundException;
	public List<ArtWork> viewArtworks() throws ArtWorkNotFoundException, SQLException, ClassNotFoundException;
	public int addArtworktoGallery(int artWorkId,int galleryId ) throws ArtWorkNotFoundException, SQLException, ClassNotFoundException,GalleryNotFoundException;
	
}
