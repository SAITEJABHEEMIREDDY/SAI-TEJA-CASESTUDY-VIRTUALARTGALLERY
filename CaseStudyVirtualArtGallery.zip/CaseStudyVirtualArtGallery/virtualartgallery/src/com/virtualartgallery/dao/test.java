package com.virtualartgallery.dao;

import static org.junit.jupiter.api.Assertions.fail;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.jupiter.api.Test;

class test {

	@BeforeClass
	static void setUpBeforeClass() throws Exception {
		System.out.println("before class");	}

	@AfterClass
	static void tearDownAfterClass() throws Exception {
		System.out.println("after class");	}
	

	
	public void setUp() throws Exception {
		
		System.out.println("before");
		
	}

	@After
	void tearDown() throws Exception {
		System.out.println("after ");
	}

	@Test
	void test() {
		System.out.println("test1");
	}

}
