package com.virtualartgallery.exception;

public class ArtistNotFoundException extends Exception {

	private static final long serialVersionUID = 1L;

	public ArtistNotFoundException() {
		// TODO Auto-generated constructor stub
	}

	public ArtistNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
