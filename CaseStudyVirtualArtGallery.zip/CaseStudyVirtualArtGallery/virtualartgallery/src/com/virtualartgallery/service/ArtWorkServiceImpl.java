package com.virtualartgallery.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.virtualartgallery.dao.ArtWorkDAOImpl;
import com.virtualartgallery.dao.IArtWorkDAO;
import com.virtualartgallery.entity.ArtWork;
import com.virtualartgallery.exception.ArtWorkNotFoundException;
import com.virtualartgallery.exception.GalleryNotFoundException;

public class ArtWorkServiceImpl implements IArtWorkService {

	IArtWorkDAO iArtWorkDAO;
	
	public  ArtWorkServiceImpl() {
		
		iArtWorkDAO = new ArtWorkDAOImpl();
		
	}
	
	@Override
	public int addArtWork(ArtWork artwork) {
		
		int res = 0;
		
		try {
			res = iArtWorkDAO.addArtWork(artwork);
		}catch(SQLException s) {
			System.out.println("Either url,username,password or Query are wrong");
		}catch(ClassNotFoundException cnfe) {
			System.out.println("JDBC not connected to DataBase");
		}catch(IllegalArgumentException iae) {
			System.out.println("Enter Date in mentioned Format only");
		}
		return res;
		
	}

	@Override
	public int updateArtWork(ArtWork artwork) {
		
		int res = 0;
		
		try {
			res = iArtWorkDAO.updateArtWork(artwork);
		}catch(SQLException s) {
			s.printStackTrace();
			System.out.println("Either url,username,password or Query are wrong");
		}catch(ClassNotFoundException cnfe) {
			System.out.println("JDBC not connected to DataBase");
		}catch(IllegalArgumentException iae) {
			System.out.println("Enter Date in mentioned Format only");
		}catch(ArtWorkNotFoundException awn) {
			System.out.println("ArtWork Not Found");
		}
		return res;

	}

	@Override
	public int removeArtWork(int artWorkId) {
		
		int res = 0;
		
		try {
			res = iArtWorkDAO.removeArtWork(artWorkId);
		}catch(SQLException s) {
			s.printStackTrace();
			System.out.println("Either url,username,password or Query are wrong");
		}catch(ClassNotFoundException cnfe) {
			System.out.println("JDBC not connected to DataBase");
		}catch(ArtWorkNotFoundException awn) {
			System.out.println("ArtWork Not Found");
		}
		return res;

	}

	@Override
	public ArtWork getArtWorkById(int artWorkId) {
		ArtWork artwork = null;
		
		try {
			artwork = iArtWorkDAO.getArtWorkById(artWorkId);
		}catch(SQLException s) {
			s.printStackTrace();
			System.out.println("Either url,username,password or Query are wrong");
		}catch(ClassNotFoundException cnfe) {
			System.out.println("JDBC not connected to DataBase");
		}catch(ArtWorkNotFoundException awn) {
			System.out.println("ArtWork Not Found");
		}
		
		return artwork;
	}

	@Override
	public List<ArtWork> searchArtworks(String keyword) {
		List<ArtWork> artworks = null;
		
		try {
			artworks = iArtWorkDAO.searchArtworks(keyword);
		}catch(SQLException s) {
			s.printStackTrace();
			System.out.println("Either url,username,password or Query are wrong");
		}catch(ClassNotFoundException cnfe) {
			System.out.println("JDBC not connected to DataBase");
		}catch(ArtWorkNotFoundException awn) {
			System.out.println("ArtWork Not Found");
		}
		return artworks;
	}
	
	public List<ArtWork> viewArtworks(){
		List<ArtWork> artworks = new ArrayList<>();
		
		try {
			artworks = iArtWorkDAO.viewArtworks();
		}catch(SQLException s) {
			s.printStackTrace();
			System.out.println("Either url,username,password or query are wrong");
		}catch(ClassNotFoundException cnfe) {
			System.out.println("JDBC not connected to DataBase");
		}catch(ArtWorkNotFoundException anfe){
			System.out.println("Artist Not Found ");
		}
		
		return artworks;
	}

	public int addArtworktoGallery(int artWorkId,int galleryId ) {
		int res =0;
		try {
			res = iArtWorkDAO.addArtworktoGallery(artWorkId,galleryId);
		}catch(SQLException s) {
			s.printStackTrace();
			System.out.println("Either url,username,password or query are wrong");
		}catch(ClassNotFoundException cnfe) {
			System.out.println("JDBC not connected to DataBase");
		}catch(ArtWorkNotFoundException anfe){
			anfe.printStackTrace();
			System.out.println("ArtWork Not Found ");
		}catch(GalleryNotFoundException ge) {
			System.out.println("Gallery Not Found Enter Correct Gallery ID");	}
		
		return res;
		
	}
	
}
