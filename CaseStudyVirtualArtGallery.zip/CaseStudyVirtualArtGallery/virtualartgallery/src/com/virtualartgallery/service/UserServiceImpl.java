package com.virtualartgallery.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import com.virtualartgallery.dao.IUserDAO;
import com.virtualartgallery.dao.UserDAOImpl;
import com.virtualartgallery.entity.ArtWork;
import com.virtualartgallery.entity.User;
import com.virtualartgallery.exception.ArtWorkNotFoundException;
import com.virtualartgallery.exception.FavArtWorkNotFoundException;
import com.virtualartgallery.exception.UserNotFoundException;

public class UserServiceImpl implements IUserService {
	
	private IUserDAO iUserDAO;
	Connection connection;
	
	public UserServiceImpl() {
		super();
		iUserDAO = new UserDAOImpl();
	}

	@Override
	public int addUser(User user) {
		int result = 0;
		try {
			
			result = iUserDAO.addUser(user);
		}catch(ClassNotFoundException cfne) {
			System.out.println("Looks like JDBC driver is not loaded");
		}catch(SQLException s) {
			s.printStackTrace();
			System.out.println("Either url,username or password is wrong or duplicate record");
		}catch(IllegalArgumentException iae) {
			System.out.println("Enter Date in mentioned format only");
		}catch(FileNotFoundException fnfe) {
			System.out.println("File Not Found Enter correct path");
		}catch(IOException ioe) {
			System.out.println("Enter correct path of image");
		}
		return result;
	}

	
	@Override
	public int updateUser(User user) {
		int result =0;
		
		try {
			result = iUserDAO.updateUser(user);
		}catch(ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC  is not loaded");
		}catch(SQLException s) {
			System.out.println("Either url,username or password");
		}catch(UserNotFoundException u) {
			System.out.println(u.getMessage());
		}catch(IllegalArgumentException iae) {
			System.out.println("Incorrect Date Format");
		}
		
		return result;
	}

	@Override
	public int deleteUser(int userId) {
		
		int result =0;
		
		try {
			result = iUserDAO.deleteUser(userId);
		}catch(ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC  is not loaded");
		}catch(SQLException s) {
			System.out.println("Either url,username or password");
			
		}catch(UserNotFoundException u) {
			System.out.println(u.getMessage());
		}
		
		return result;
	}

	@Override
	public User viewUser(int userId) {
		User user = null;
		
		try {
			user = iUserDAO.viewUser(userId);
		}catch(ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC  is not loaded");
		}catch(SQLException s) {
			System.out.println("Either url,username or password");
			
		}catch(UserNotFoundException u) {
			System.out.println(u.getMessage());
		}catch(FileNotFoundException fnfe) {
			System.out.println("File Not Found");
		}catch(IOException ioe) {
			System.out.println("Enter Correct path");
		}
		return user;
	}

	@Override
	public List<User> viewUsers(){
		List<User>userList = null;
		
		try {
			userList = iUserDAO.viewUsers();
		}catch(ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC  is not loaded");
		}catch(SQLException s) {
			System.out.println("Either url,username or password");
			
		}catch(UserNotFoundException u) {
			System.out.println(u.getMessage());
		}
		
		return userList;
	}
	
	@Override
	public int addArtworkToFavorite(int userId, int artWorkId) {
		int res = 0;
		try {
			res = iUserDAO.addArtworkToFavorite(userId,artWorkId);
		}catch(SQLException s) {
			s.printStackTrace();
			System.out.println("Either url,username,password or Query are wrong");
		}catch(ClassNotFoundException cnfe) {
			System.out.println("JDBC not connected to DataBase");
		}catch(ArtWorkNotFoundException awn) {
			System.out.println("ArtWork Not Found");
		}catch(UserNotFoundException unfe) {
			System.out.println("User Not Found");
		}catch(FavArtWorkNotFoundException fne) {
			System.out.println(fne.getMessage());
		}
		return res;

	}

	
	@Override
	public int removeArtworkFromFavorite(int userId, int artWorkId) {
		int res = 0;
		try {
			res = iUserDAO.removeArtworkFromFavorite(userId,artWorkId);
		}catch(SQLException s) {
			s.printStackTrace();
			System.out.println("Either url,username,password or Query are wrong");
		}catch(ClassNotFoundException cnfe) {
			System.out.println("JDBC not connected to DataBase");
		}catch(ArtWorkNotFoundException awn) {
			System.out.println(awn.getMessage());
		}catch(UserNotFoundException unfe) {
			System.out.println(unfe.getMessage());
		}catch(FavArtWorkNotFoundException fwne) {
			System.out.println(fwne.getMessage());
		}
		return res;
	}
	
	@Override
	public List<ArtWork> getUserFavoriteArtworks(int userId) {
		List<ArtWork> artworks= null;
		
		try {
			artworks = iUserDAO.getUserFavoriteArtworks(userId);
		}catch(SQLException s) {
			s.printStackTrace();
			System.out.println("Either url,username,password or Query are wrong");
		}catch(ClassNotFoundException cnfe) {
			System.out.println("JDBC not connected to DataBase");
		}catch(FavArtWorkNotFoundException fawn) {
			System.out.println(fawn.getMessage());
		}catch(UserNotFoundException unfe) {
			System.out.println(unfe.getMessage());
		}
		return artworks;
	}
	}



