package com.virtualartgallery.service;

import java.util.List;

import com.virtualartgallery.entity.Gallery;


public interface IGalleryService {
	
	public int addGallery(Gallery gallery) ;
	public int updateGallery(Gallery gallery) ;
	public int deleteGallery(int galleryId) ;
	public Gallery viewGallery(int galleryId) ;
	public List<Gallery>viewGallerys();

}
