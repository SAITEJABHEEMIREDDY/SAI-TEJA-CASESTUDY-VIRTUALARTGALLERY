package com.virtualartgallery.service;

import java.util.List;

import com.virtualartgallery.entity.ArtWork;
import com.virtualartgallery.entity.User;

public interface IUserService {
	
	public int addUser(User user);
	public int updateUser(User user);
	public int deleteUser(int userId);
	public User viewUser(int userId);
	public List<User> viewUsers() ;
	
	public int addArtworkToFavorite(int userId,int artWorkId);
	public int removeArtworkFromFavorite(int userId, int artWorkId)  ;
	public List<ArtWork> getUserFavoriteArtworks(int userId) ;
	

}
