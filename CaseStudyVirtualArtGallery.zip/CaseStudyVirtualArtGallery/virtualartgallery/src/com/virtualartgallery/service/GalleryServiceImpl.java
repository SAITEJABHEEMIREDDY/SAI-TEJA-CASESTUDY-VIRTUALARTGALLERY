package com.virtualartgallery.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.virtualartgallery.dao.GalleryDAOImpl;
import com.virtualartgallery.dao.IGalleryDAO;
import com.virtualartgallery.entity.Gallery;
import com.virtualartgallery.exception.GalleryNotFoundException;

public class GalleryServiceImpl implements IGalleryService {

	IGalleryDAO iGalleryDAO;
	
	public GalleryServiceImpl() {
		iGalleryDAO = new GalleryDAOImpl();
	}
	@Override
	public int addGallery(Gallery gallery) {
		int result = 0;
		try {
			result = iGalleryDAO.addGallery(gallery);
		}catch(ClassNotFoundException cfne) {
			System.out.println("Looks like JDBC driver is not loaded");
		}catch(SQLException s) {
			s.printStackTrace();
			System.out.println("Either url,username or password is wrong or duplicate record");
		}
		return result;
	}

	@Override
	public int updateGallery(Gallery gallery) {
		int result = 0;
		try {
			result = iGalleryDAO.updateGallery(gallery);
		}catch(SQLException s) {
			System.out.println("Error in your Query");
			s.getMessage();
		}catch(GalleryNotFoundException gnfe) {
			System.out.println("Gallery Not Found Enter Correct Gallery ID");
			gnfe.getMessage();
		}catch(ClassNotFoundException cnfe) {
			System.out.println("JDBC is not Connected Properly");
			cnfe.getMessage();
		}
		
		return result;
	}

	@Override
	public int deleteGallery(int galleryId) {
		int result = 0;
		try {
			result = iGalleryDAO.deleteGallery(galleryId);
		}catch(ClassNotFoundException cfne) {
			System.out.println("Looks like JDBC driver is not loaded");
		}catch(SQLException s) {
			s.printStackTrace();
			System.out.println("Either url,username or password is wrong or duplicate record");
		}catch(GalleryNotFoundException gnfe) {
			System.out.println("Gallery Not Found");
		}
		
		return result;
	}

	@Override
	public Gallery viewGallery(int galleryId) {
		Gallery gallery = null;
		try {
			gallery = iGalleryDAO.viewGallery(galleryId);
		}catch(ClassNotFoundException cfne) {
			System.out.println("Looks like JDBC driver is not loaded");
		}catch(SQLException s) {
			System.out.println("Either url,username or password is wrong or duplicate record");
		}catch(GalleryNotFoundException gnfe) {
			System.out.println("Gallery Not Found Enter Correct GalleryID");
		}
		return gallery;
	}

	@Override
	public List<Gallery> viewGallerys() {
		List<Gallery> galleryList = new ArrayList<>();
		try {
			galleryList = iGalleryDAO.viewGallerys();
		}catch(ClassNotFoundException cfne) {
			System.out.println("Looks like JDBC driver is not loaded");
		}catch(SQLException s) {
			s.printStackTrace();
			System.out.println("Either url,username or password is wrong or duplicate record");
		}catch(GalleryNotFoundException gnfe) {
			System.out.println("Gallery Not Found Enter Correct GalleryID");
		}
		return galleryList;
	}

}
