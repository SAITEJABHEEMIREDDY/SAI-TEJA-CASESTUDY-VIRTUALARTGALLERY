package com.virtualartgallery.entity;

public class Gallery {
		
		private int galleryId;
		private String name;
		private String location;
		private String description;
		private Artist artist;
		private String openingHour;
		
		public Gallery() {
			super();
		}
		
		public Gallery(String name, String location, String description,String openingHour, Artist artist) {
			
			this.name = name;
			this.description = description;
			this.location = location;
			this.artist = artist;
			this.openingHour = openingHour;
			
		}
		
		// Constructor
		public Gallery(int galleryId, String name, String location,String description ,String openingHour, Artist artist) {
			
			this.galleryId = galleryId;
			this.name = name;
			this.description= description;
			this.location = location;
			this.artist = artist;
			this.openingHour = openingHour;
			
		}
		
		
		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getLocation() {
			return location;
		}

		public void setLocation(String location) {
			this.location = location;
		}

		

		public String getDescription() {
			return description;
		}

		public void setDescription(String description) {
			this.description = description;
		}

		public Artist getArtist() {
			return artist;
		}

		public void setArtist(Artist artist) {
			this.artist = artist;
		}

		public void setGalleryId(int galleryId) {
			this.galleryId = galleryId;
		}

		public String getOpeningHour() {
			return openingHour;
		}

		public void setOpeningHour(String openingHour) {
			this.openingHour = openingHour;
		}

		public int getGalleryId() {
			return galleryId;
		}

		@Override
		public String toString() {
			return "Gallery [galleryId=" + galleryId + ", name=" + name + ", location=" + location + ", description="
					+ description + ", artist=" + artist + ", openingHour=" + openingHour + "]";
		}

		

		
		
}

