package com.virtualartgallery.main;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.virtualartgallery.entity.ArtWork;
import com.virtualartgallery.entity.Artist;
import com.virtualartgallery.entity.Gallery;
import com.virtualartgallery.entity.User;
import com.virtualartgallery.service.ArtWorkServiceImpl;
import com.virtualartgallery.service.ArtistServiceImpl;
import com.virtualartgallery.service.GalleryServiceImpl;
import com.virtualartgallery.service.IArtWorkService;
import com.virtualartgallery.service.IArtistService;
import com.virtualartgallery.service.IGalleryService;
import com.virtualartgallery.service.IUserService;
import com.virtualartgallery.service.UserServiceImpl;



public class MainModule {

	public static void main(String[] args) {
		
		
		
		IArtistService artistService = new ArtistServiceImpl();
		IArtWorkService artworkService = new ArtWorkServiceImpl();
		IUserService userService = new UserServiceImpl();
		IGalleryService galleryService = new GalleryServiceImpl();
		
		
		
		User user = null;
		Artist artist = null;
		ArtWork artwork = null;
		Gallery gallery = null;
		
		int artistId = 0;
		String name;
		String biography;
		String birthDate;
		String nationality;
		String website;
	    String contactInformation;
		
		
		
		int artWorkId = 0;
		String title;
		String creationDate;
		String medium;
		String imageUrl;
		
		
		
		int userId = 0;
		String userName ;
		String passWord;
		String email;
		String firstName;
		String lastName;
		String dateOfBirth;
		String profilePicture;
		
		
	
		int galleryId = 0;
		String galleryName;
		String description;
		String location;
		String openingHour;
		
		int success = 0;
		
		
		int choice = -1;
		
		Scanner scInput = new Scanner(System.in);
		
		while(choice!=0) {
			
			System.out.println("Choose below options:");
			System.out.println("1. ArtWork");
			System.out.println("2. Artist");
			System.out.println("3. User");
			System.out.println("4. Gallery");
			
			
			
			System.out.println("Enter your choice:");
			
			choice = scInput.nextInt();
			         scInput.nextLine();
			
			switch(choice) {
			
			case 1:
				
				int innerChoice = -1;
				while(innerChoice !=0) {
					
					System.out.println("Choose below options:");
					System.out.println("1. Insert ArtWork");
					System.out.println("2. Update ArtWork");
					System.out.println("3. Delete ArtWork");
					System.out.println("4. View ArtWork by ID");
					System.out.println("5. View all ArtWorks");
					System.out.println("6. Search ArtWork by Keyword");
					System.out.println("7. Add Artwork to Gallery");
					System.out.println("0. Exit");
					System.out.println("Please Enter your choice");
					innerChoice = scInput.nextInt();
					              scInput.nextLine();
					
				switch(innerChoice) {

				case 1:
					System.out.println("You are choosen to Add ArtWork");
					System.out.println("Enter Title of ArtWork:");
					title = scInput.nextLine();
					
					System.out.println("Enter Description of ArtWork:");
					description = scInput.nextLine();
					
					System.out.println("Enter CreationDate of ArtWork:YYYY-MM-DD");
					creationDate = scInput.nextLine();
					
					System.out.println("Enter Medium of ArtWork ");
					medium = scInput.nextLine();
					
					System.out.println("Enter ImageURL of ArtWork ");
					imageUrl = scInput.nextLine();
					
					artwork = new ArtWork(title,description,creationDate,medium,imageUrl);
					
					success = artworkService.addArtWork(artwork);
					
					if (success==1) {
						System.out.println("ArtWork added Successfully..");
					}
				    break;
				case 2:
					System.out.println("You are choosen to Add ArtWork");
					
					System.out.println("Enter ArtWorkID:");
				    artWorkId = scInput.nextInt();
				    scInput.nextLine();
					
					System.out.println("Enter Title of ArtWork:");
					title = scInput.nextLine();
					
					System.out.println("Enter Description of ArtWork:");
					description = scInput.nextLine();
					
					System.out.println("Enter CreationDate of ArtWork:YYYY-MM-DD");
					creationDate = scInput.nextLine();
					
					System.out.println("Enter Medium of ArtWork ");
					medium = scInput.nextLine();
					
					System.out.println("Enter ImageURL of ArtWork ");
					imageUrl = scInput.nextLine();
					
					artwork = new ArtWork(title,description,creationDate,medium,imageUrl);
					
					artwork.setArtworkId(artWorkId);
					
					success = artworkService.updateArtWork(artwork);
					
					if (success==1) {
						System.out.println("ArtWork Updated Successfully..");
					}
				    break;
				case 3:
					System.out.println("You are choosen to Delete ArtWork");
					
					System.out.println("Enter ArtWorkID:");
				    artWorkId = scInput.nextInt();
				    scInput.nextLine();
				    
				    success = artworkService.removeArtWork(artWorkId);
				    
				    if (success==1) {
						System.out.println("ArtWork Deleted Successfully..");
					}
				    
				    break;
				    
				case 4:
					
					System.out.println("You are choosen to get ArtWork by ID");
					
					System.out.println("Enter ArtWorkID:");
				    artWorkId = scInput.nextInt();
				    scInput.nextLine();
				    
				    artwork = artworkService.getArtWorkById(artWorkId);
				    
				    if (artwork!=null) {
				    System.out.println(artwork);
				    }
				    
				    break;
				case 5:
					
					List<ArtWork> artworksList = null;
					
					artworksList = artworkService.viewArtworks();
					
					for(ArtWork artwork1 : artworksList) {
						System.out.println(artwork1);
					}
				    break;
				case 6:
					
					List<ArtWork> artworks = null;
					
					System.out.println("Enter keyword to Search Artworks:");
					
					String keyword = scInput.nextLine();
					
					artworks = artworkService.searchArtworks(keyword);
					
					if (artworks!=null) {
						
					   for(ArtWork artwork1:artworks) {
						
						   System.out.println(artwork1);
					}
					}
					
					break;
				case 7:
					System.out.println("Enter artworkid:");
					int artworkId = scInput.nextInt();
					System.out.println("Enter Gallery ID");
					galleryId = scInput.nextInt();
					
					success = artworkService.addArtworktoGallery(artworkId,galleryId);
					
					if(success ==1) {
						System.out.println("Gallery_ArtWok added Successfully");
					}
					
					
				}	
				
				}
				
				break;
				
			
			case 2:
				
				int innerChoice2 = -1;
				while(innerChoice2 !=0) {
					
					System.out.println("Choose below options:");
					System.out.println("1. Insert Artist");
					System.out.println("2. Update Artist");
					System.out.println("3. Delete Artist");
					System.out.println("4. View Artist by ID");
					System.out.println("5. View all Artists");
					System.out.println("0. Exit");
					System.out.println("Please Enter your choice");
					innerChoice2 = scInput.nextInt();
					              scInput.nextLine();
					              
					switch(innerChoice2) {
					case 1:
						
						System.out.println("Enter Artist Name:");
						name = scInput.nextLine();
						
						System.out.println("Enter Artist biography:");
						biography = scInput.nextLine();
						
						System.out.println("Enter Date Of Birth:YYYY-MM-DD");
						birthDate  = scInput.nextLine();
						
						System.out.println("Enter Artist Nationality:");
						nationality = scInput.nextLine();
						
						System.out.println("Enter Artist Website:");
						website = scInput.nextLine();
						
						System.out.println("Enter Artist contactInformation");
						contactInformation = scInput.nextLine();
						
						
						
						artist = new Artist(name,biography,birthDate,nationality,website,contactInformation);
						
						success = artistService.addArtist(artist);
						
						if(success == 1) {
							System.out.println("Artist Added Succesfully");
						}
						
						break;
					case 2:
						System.out.println("You are choosen to Update Artist:");
						
						System.out.println("Enter Artist Id");
						artistId = scInput.nextInt();
						           scInput.nextLine();
						
						System.out.println("Enter Artist Name:");
						name = scInput.nextLine();
						
						System.out.println("Enter Artist biography:");
						biography = scInput.nextLine();
						
						System.out.println("Enter Date Of Birth: YYYY-MM-DD");
						birthDate  = scInput.nextLine();
						
						System.out.println("Enter Artist Nationality:");
						nationality = scInput.nextLine();
						
						System.out.println("Enter Artist Website:");
						website = scInput.nextLine();
						
						System.out.println("Enter Artist contactInformation");
						contactInformation = scInput.nextLine();
						
						
						artist = new Artist(artistId,name,biography,birthDate,nationality,website,contactInformation);
						
						success = artistService.updateArtist(artist);
						
						if(success == 1) {
							System.out.println("Artist Updated Succesfully");
						}
						
						break;
					case 3:
						System.out.println("You are choosen to DELETE Artist");
						System.out.println("Enter ArtistId To DELETE");
						artistId = scInput.nextInt();
						           scInput.nextLine();
						           
						success = artistService.deleteArtist(artistId);
						
						if(success ==1 ) {
							System.out.println("Artist with " +artistId+ " DELETED Successfully");

						}
						
						
						break;
					case 4:
						
						
						System.out.println("Enter ArtistId To View");
						artistId = scInput.nextInt();
						           scInput.nextLine();
						           
						artist = artistService.viewArtist(artistId);
						
						if(artist!=null ) {
							System.out.println(artist);

						}
						
						
						break;
					case 5:
						
						List<Artist>  artistList = new ArrayList<>();
						
						artistList = artistService.viewArtists();
						
						
						if(artistList.size()!=0) {
							
							for(Artist artist1:artistList) {
								System.out.println(artist1);
							}
							
						}
						
						
						break;
						
					}
				}
				break;
				
            case 3:
				
				int innerChoice3 = -1;
				while(innerChoice3 !=0) {
					
					System.out.println("Choose below options:");
					System.out.println("1. Insert User");
					System.out.println("2. Update User");
					System.out.println("3. Delete User");
					System.out.println("4. View User by ID");
					System.out.println("5. View all Users");
					System.out.println("6. Add Artwork To User Favorites");
					System.out.println("7. Remove Artwork From User Favorites");
					System.out.println("8. Get all User Favorites");
					System.out.println("0. Exit");
					System.out.println("Please Enter your choice");
					innerChoice3 = scInput.nextInt();
					              scInput.nextLine();
					
					switch(innerChoice3){
						
					case 1:
						System.out.println("Enter Username :");
						userName = scInput.nextLine();
						
						System.out.println("Enter your Password:");
						passWord = scInput.nextLine();
						
					    System.out.println("Enter your Email:");
						email = scInput.nextLine();
						
						System.out.println("Enter your FirstName:");
						firstName = scInput.nextLine();
						
						System.out.println("Enter yout LastName:");
						lastName = scInput.nextLine();
						
						System.out.println("Enter your DateofBirth:YYYY-MM-DD");
						dateOfBirth = scInput.nextLine();
						
						System.out.println("Enter path of ProfilePicture");
						profilePicture = scInput.nextLine();
						
						user = new User(userName,passWord,email,firstName,lastName,dateOfBirth,profilePicture);
						
						
						success = userService.addUser(user);
						
						if (success == 1) {
							System.out.println("Record Inserted Successfully..");
						}
						
						break;
					case 2:
						System.out.println("Enter UserId");
						userId = scInput.nextInt();
						         scInput.nextLine();
						System.out.println("Enter Username :");
						userName = scInput.nextLine();
						
						System.out.println("Enter your Password:");
						passWord = scInput.nextLine();
						
					    System.out.println("Enter your Email:");
						email = scInput.nextLine();
						
						System.out.println("Enter your FirstName:");
						firstName = scInput.nextLine();
						
						System.out.println("Enter yout LastName:");
						lastName = scInput.nextLine();
						
						System.out.println("Enter your DateofBirth:YYYY-MM-DD");
						dateOfBirth = scInput.nextLine();
						
						System.out.println("Enter path of ProfilePicture");
						profilePicture = scInput.nextLine();
						
						user = new User(userId ,userName,passWord,email,firstName,lastName,dateOfBirth,profilePicture);
						
						success = userService.updateUser(user);
						
						if (success == 1) {
							System.out.println("Record Updated Successfully..");
						}
						
						break;
					case 3:
						System.out.println("Enter UserId to Delete:");
						userId = scInput.nextInt();
						int result = userService.deleteUser(userId);	
						if(result != 0) {
							System.out.println("Deleted Successfully");
						}
						break;
					case 4:
						System.out.println("Enter UserId");
						int userId1 = scInput.nextInt();
						user = userService.viewUser(userId1);
						
						if(user != null) {
							System.out.println(user);
						}
						break;
					case 5:
						
						List<User>userList = userService.viewUsers();
						
						System.out.println("Following are the users");
						
						if(userList.size()!=0) {
						for(User user1:userList) {
							System.out.println(user1);
						}
						}
						break;
					case 6:
						System.out.println("You are Choosen to Add ArtWork to User Favorites");
						System.out.println("Enter UserId:");
						userId = scInput.nextInt();
						    	scInput.nextLine();
						System.out.println("Enter ArtworkId");
						artWorkId = scInput.nextInt();
						            scInput.nextLine();
						
						success = userService.addArtworkToFavorite(userId,artWorkId);
						
						if(success==1) {
							System.out.println("ArtWork added to User Favorites");
							
						}
						//Add exception what if that artwork is already existing in User favourites
						break;
					case 7:
						System.out.println("You are Choosen to Remove ArtWork to User Favorites");
						System.out.println("Enter UserId:");
						userId = scInput.nextInt();
						    	scInput.nextLine();
						System.out.println("Enter ArtworkId");
						artWorkId = scInput.nextInt();
						            scInput.nextLine();
						
						success = userService.removeArtworkFromFavorite(userId,artWorkId);
						
						if(success==1) {
							System.out.println("ArtWork added to User Favorites");
							
						}
						
						break;
					case 8:
						
						List<ArtWork> userFavsArts = new ArrayList<>();
						
						System.out.println("Enter UserId");
						
						userId  = scInput.nextInt();
						scInput.nextLine();
						
						userFavsArts = userService.getUserFavoriteArtworks(userId);
						
						if(userFavsArts!=null) {
							
							for(ArtWork artwork1 : userFavsArts) {
								
								System.out.println(artwork1);
								
							}
							
						}
						break;
						
						
					}
				}
			
			case 4:
				
				int inChoice = -1;
				while(inChoice !=0) {
					System.out.println("Choose below options:");
					System.out.println("1. Insert Gallery");
					System.out.println("2. Update Gallery");
					System.out.println("3. Delete Gallery");
					System.out.println("4. View Gallery By ID");
					System.out.println("5. View All Galleries");
					inChoice = scInput.nextInt();
					           scInput.nextLine();
					
					switch(inChoice) {
					
					case 1:
						System.out.println("Enter GalleryName");
						galleryName = scInput.nextLine();
						
						System.out.println("Enter Description");
						description = scInput.nextLine();
						
						System.out.println("Enter Location");
						location = scInput.nextLine();
						
						System.out.println("Enter OpeningHour");
						openingHour = scInput.nextLine();
						
						System.out.println("Enter ArtistId");
						artistId = scInput.nextInt();
						           scInput.nextLine();
						           
						
						artist = new Artist();
						
						artist.setArtistId(artistId);
						
						gallery = new Gallery(galleryName,location,description,openingHour,artist);
						
						success = galleryService.addGallery(gallery);
						
						if(success == 1) {
							System.out.println("Inserted Gallery Successfully...");
						}
						
						break;
					case 2:
						
						System.out.println("Enter GalleryId");
						galleryId = scInput.nextInt();
						                scInput.nextLine();
						System.out.println("Enter GalleryName");
						galleryName = scInput.nextLine();
						
						System.out.println("Enter Description");
						description = scInput.nextLine();
						
						System.out.println("Enter Location");
						location = scInput.nextLine();
						
						System.out.println("Enter OpeningHour");
						openingHour = scInput.nextLine();
						
						System.out.println("Enter ArtistId");
						artistId = scInput.nextInt();
						           scInput.nextLine();
						
						           
						Artist artist2 = new Artist();
						artist2.setArtistId(artistId);
						
						
						Gallery gallery2 = new Gallery(galleryId,galleryName,location,description,openingHour,artist2);
						
					    success = galleryService.updateGallery(gallery2);
						 
					    if(success == 1) {
					    	System.out.print("Gallery updated Successfully");
					    }
					    
						break;
						
						
					case 3:
						System.out.println("You choose to Delete Gallery..");
						System.out.println("Enter GalleryId");
						galleryId = scInput.nextInt();
						
						success = galleryService.deleteGallery(galleryId);
						
						if(success == 1) {
							System.out.println("Deletion of Gallery with galleryId "+galleryId+" Successfull");
							
						}else {
							System.out.println("Deletion Failed");
						}
						
						break;
					case 4:
						System.out.println("Enter GalleryID:");
						galleryId = scInput.nextInt();
						gallery =  galleryService.viewGallery(galleryId);
						
						if(gallery!= null) {
							System.out.println(gallery);
						}
						
						break;
					case 5:
						List<Gallery> galleryList = new ArrayList<>();
						
						galleryList =  galleryService.viewGallerys();
						
						
						if(galleryList.size()!=0) {
							for(Gallery gallery1:galleryList) {
								System.out.println(gallery1);
							}
						}		
			 			
				    }	
				
				}
						
		    }
					
	     }
		
			
		scInput.close();
		
	}
}


