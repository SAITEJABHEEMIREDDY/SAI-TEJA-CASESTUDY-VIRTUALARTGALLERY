package com.virtualartgallery.util;

import java.util.ResourceBundle;

public class PropertyUtil {
	
	public static String getPropertyString() {
		
		ResourceBundle resMySQL = ResourceBundle.getBundle("mysql");
		 
		String hostname =  resMySQL.getString("hostname");
		String username = resMySQL.getString("username");
		String password = resMySQL.getString("password");
		String dbname = resMySQL.getString("dbname");
		String portnumber = resMySQL.getString("portnumber");
		
		String connectionString = "jdbc:mysql://"+hostname+":"+portnumber+"/"+dbname+"?user="+username+"&password="+password;
		return connectionString;
		

	}

}
